# Bug Squasher — راه‌اندازی جدول امتیازات (یک‌بار، حدود ۱۰ دقیقه)

بازی و بقیه بخش‌ها (امتیاز، رکورد شخصی، اسم) بدون هیچ تنظیماتی روی هر هاستی کار می‌کنن.
فقط «جدول امتیازات» چون باید بین همه‌ی بازیکن‌ها مشترک باشه، به یک دیتابیس رایگان
Supabase نیاز داره — که برخلاف Firebase، برای پلن رایگانش کارت بانکی لازم نداره.
تا وقتی این تنظیمات انجام نشه، بازی کاملاً درست کار می‌کنه و فقط توی صفحه‌ی جدول
امتیازات یک پیام «هنوز تنظیم نشده» نشون داده میشه.

## مرحله ۱ — ساخت پروژه Supabase

1. برو به https://supabase.com و روی **Start your project** بزن. می‌تونی با گیت‌هاب
   یا ایمیل ثبت‌نام کنی — نیازی به کارت بانکی نیست.
2. روی **New project** بزن، یک اسم بده (مثلاً `bug-squasher`)، یک رمز عبور دیتابیس
   بساز (جایی نگهش دار، لازمش نداری ولی برای بعداً خوبه) و نزدیک‌ترین Region رو
   انتخاب کن.
3. چند ثانیه تا چند دقیقه صبر کن تا پروژه ساخته بشه.

## مرحله ۲ — ساخت جدول leaderboard

1. توی منوی سمت چپ پروژه، برو به **SQL Editor**.
2. روی **New query** بزن و کد زیر رو کامل کپی/پیست کن، بعد **Run** بزن:

```sql
create table leaderboard (
  name_key text primary key,
  name text not null,
  score integer not null,
  updated_at timestamptz not null default now()
);

alter table leaderboard enable row level security;

create policy "public read leaderboard"
  on leaderboard for select
  using (true);

create policy "public insert leaderboard"
  on leaderboard for insert
  with check (
    char_length(name) > 0 and char_length(name) < 30
    and score >= 0 and score < 100000
  );

create policy "public update leaderboard"
  on leaderboard for update
  using (true)
  with check (
    char_length(name) > 0 and char_length(name) < 30
    and score >= 0 and score < 100000
  );
```

این کوئری یک جدول به اسم `leaderboard` می‌سازه و قوانین امنیتی (RLS) رو طوری تنظیم
می‌کنه که همه بتونن جدول رو بخونن، ولی فقط بتونن اسم و امتیاز معتبر (بین ۰ تا ۱۰۰۰۰۰
و اسم کمتر از ۳۰ کاراکتر) ثبت کنن — نه هر داده‌ی دلخواهی.

## مرحله ۳ — گرفتن URL و کلید پروژه

1. توی منوی سمت چپ برو به **Project Settings → API** (آیکون چرخ‌دنده پایین سایدبار).
2. دو مقدار رو از اونجا کپی کن:
   - **Project URL** (چیزی شبیه `https://xxxxxxxxxx.supabase.co`)
   - **anon public** key (یک رشته‌ی طولانی زیر بخش Project API keys — ممکنه با اسم
     "publishable key" هم نشون داده بشه)

## مرحله ۴ — جایگذاری توی فایل

1. فایل `index.html` رو باز کن، دنبال این دو خط بگرد (نزدیک بالای تگ `<script>` اصلی):

```js
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
```

2. مقادیرشون رو با چیزی که از مرحله‌ی ۳ کپی کردی جایگزین کن، مثلاً:

```js
const SUPABASE_URL = "https://xxxxxxxxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
```

3. فایل رو ذخیره کن و دوباره روی هر هاست استاتیکی (Netlify Drop، Cloudflare Pages و ...) دیپلویش کن.

## تست

بعد از دیپلوی، یک بار بازی کن تا کرش بشه، بعد از منو روی «🏆 جدول امتیازات» بزن —
باید اسم و امتیازت رو ببینی. با یک مرورگر یا گوشی دیگه هم امتحان کن تا مطمئن بشی
جدول واقعاً بین چند نفر مشترکه.

## نکته

پلن رایگان Supabase تا ۵۰۰ مگابایت دیتابیس و ۵۰ هزار کاربر فعال ماهانه رایگان میده —
برای یک دموی داخلی حتی استفاده‌ی عمومی سبک، کاملاً کافیه.
